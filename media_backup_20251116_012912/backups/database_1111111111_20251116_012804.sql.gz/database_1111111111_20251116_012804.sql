/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=241 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add user',6,'add_user'),(22,'Can change user',6,'change_user'),(23,'Can delete user',6,'delete_user'),(24,'Can view user',6,'view_user'),(25,'Can add user profile',7,'add_userprofile'),(26,'Can change user profile',7,'change_userprofile'),(27,'Can delete user profile',7,'delete_userprofile'),(28,'Can view user profile',7,'view_userprofile'),(29,'Can add address',8,'add_address'),(30,'Can change address',8,'change_address'),(31,'Can delete address',8,'delete_address'),(32,'Can view address',8,'view_address'),(33,'Can add Dashboard Permission',9,'add_dashboardpermission'),(34,'Can change Dashboard Permission',9,'change_dashboardpermission'),(35,'Can delete Dashboard Permission',9,'delete_dashboardpermission'),(36,'Can view Dashboard Permission',9,'view_dashboardpermission'),(37,'Can add category',10,'add_category'),(38,'Can change category',10,'change_category'),(39,'Can delete category',10,'delete_category'),(40,'Can view category',10,'view_category'),(41,'Can add product',11,'add_product'),(42,'Can change product',11,'change_product'),(43,'Can delete product',11,'delete_product'),(44,'Can view product',11,'view_product'),(45,'Can add product image',12,'add_productimage'),(46,'Can change product image',12,'change_productimage'),(47,'Can delete product image',12,'delete_productimage'),(48,'Can view product image',12,'view_productimage'),(49,'Can add product variant',13,'add_productvariant'),(50,'Can change product variant',13,'change_productvariant'),(51,'Can delete product variant',13,'delete_productvariant'),(52,'Can view product variant',13,'view_productvariant'),(53,'Can add review',14,'add_review'),(54,'Can change review',14,'change_review'),(55,'Can delete review',14,'delete_review'),(56,'Can view review',14,'view_review'),(57,'Can add wishlist',15,'add_wishlist'),(58,'Can change wishlist',15,'change_wishlist'),(59,'Can delete wishlist',15,'delete_wishlist'),(60,'Can view wishlist',15,'view_wishlist'),(61,'Can add review image',16,'add_reviewimage'),(62,'Can change review image',16,'change_reviewimage'),(63,'Can delete review image',16,'delete_reviewimage'),(64,'Can view review image',16,'view_reviewimage'),(65,'Can add cart',17,'add_cart'),(66,'Can change cart',17,'change_cart'),(67,'Can delete cart',17,'delete_cart'),(68,'Can view cart',17,'view_cart'),(69,'Can add cart item',18,'add_cartitem'),(70,'Can change cart item',18,'change_cartitem'),(71,'Can delete cart item',18,'delete_cartitem'),(72,'Can view cart item',18,'view_cartitem'),(73,'Can add coupon',19,'add_coupon'),(74,'Can change coupon',19,'change_coupon'),(75,'Can delete coupon',19,'delete_coupon'),(76,'Can view coupon',19,'view_coupon'),(77,'Can add coupon usage',20,'add_couponusage'),(78,'Can change coupon usage',20,'change_couponusage'),(79,'Can delete coupon usage',20,'delete_couponusage'),(80,'Can view coupon usage',20,'view_couponusage'),(81,'Can add saved item',21,'add_saveditem'),(82,'Can change saved item',21,'change_saveditem'),(83,'Can delete saved item',21,'delete_saveditem'),(84,'Can view saved item',21,'view_saveditem'),(85,'Can add invoice',22,'add_invoice'),(86,'Can change invoice',22,'change_invoice'),(87,'Can delete invoice',22,'delete_invoice'),(88,'Can view invoice',22,'view_invoice'),(89,'Can add order',23,'add_order'),(90,'Can change order',23,'change_order'),(91,'Can delete order',23,'delete_order'),(92,'Can view order',23,'view_order'),(93,'Can add order item',24,'add_orderitem'),(94,'Can change order item',24,'change_orderitem'),(95,'Can delete order item',24,'delete_orderitem'),(96,'Can view order item',24,'view_orderitem'),(97,'Can add order status history',25,'add_orderstatushistory'),(98,'Can change order status history',25,'change_orderstatushistory'),(99,'Can delete order status history',25,'delete_orderstatushistory'),(100,'Can view order status history',25,'view_orderstatushistory'),(101,'Can add shipping address',26,'add_shippingaddress'),(102,'Can change shipping address',26,'change_shippingaddress'),(103,'Can delete shipping address',26,'delete_shippingaddress'),(104,'Can view shipping address',26,'view_shippingaddress'),(105,'Can add refund request',27,'add_refundrequest'),(106,'Can change refund request',27,'change_refundrequest'),(107,'Can delete refund request',27,'delete_refundrequest'),(108,'Can view refund request',27,'view_refundrequest'),(109,'Can add incomplete order analytics',28,'add_incompleteorderanalytics'),(110,'Can change incomplete order analytics',28,'change_incompleteorderanalytics'),(111,'Can delete incomplete order analytics',28,'delete_incompleteorderanalytics'),(112,'Can view incomplete order analytics',28,'view_incompleteorderanalytics'),(113,'Can add incomplete order',29,'add_incompleteorder'),(114,'Can change incomplete order',29,'change_incompleteorder'),(115,'Can delete incomplete order',29,'delete_incompleteorder'),(116,'Can view incomplete order',29,'view_incompleteorder'),(117,'Can add incomplete order history',30,'add_incompleteorderhistory'),(118,'Can change incomplete order history',30,'change_incompleteorderhistory'),(119,'Can delete incomplete order history',30,'delete_incompleteorderhistory'),(120,'Can view incomplete order history',30,'view_incompleteorderhistory'),(121,'Can add incomplete order item',31,'add_incompleteorderitem'),(122,'Can change incomplete order item',31,'change_incompleteorderitem'),(123,'Can delete incomplete order item',31,'delete_incompleteorderitem'),(124,'Can view incomplete order item',31,'view_incompleteorderitem'),(125,'Can add incomplete shipping address',32,'add_incompleteshippingaddress'),(126,'Can change incomplete shipping address',32,'change_incompleteshippingaddress'),(127,'Can delete incomplete shipping address',32,'delete_incompleteshippingaddress'),(128,'Can view incomplete shipping address',32,'view_incompleteshippingaddress'),(129,'Can add recovery email log',33,'add_recoveryemaillog'),(130,'Can change recovery email log',33,'change_recoveryemaillog'),(131,'Can delete recovery email log',33,'delete_recoveryemaillog'),(132,'Can view recovery email log',33,'view_recoveryemaillog'),(133,'Can add dashboard setting',34,'add_dashboardsetting'),(134,'Can change dashboard setting',34,'change_dashboardsetting'),(135,'Can delete dashboard setting',34,'delete_dashboardsetting'),(136,'Can view dashboard setting',34,'view_dashboardsetting'),(137,'Can add admin activity',35,'add_adminactivity'),(138,'Can change admin activity',35,'change_adminactivity'),(139,'Can delete admin activity',35,'delete_adminactivity'),(140,'Can view admin activity',35,'view_adminactivity'),(141,'Can add expense',36,'add_expense'),(142,'Can change expense',36,'change_expense'),(143,'Can delete expense',36,'delete_expense'),(144,'Can view expense',36,'view_expense'),(145,'Can add email configuration',37,'add_emailconfiguration'),(146,'Can change email configuration',37,'change_emailconfiguration'),(147,'Can delete email configuration',37,'delete_emailconfiguration'),(148,'Can view email configuration',37,'view_emailconfiguration'),(149,'Can add email template',38,'add_emailtemplate'),(150,'Can change email template',38,'change_emailtemplate'),(151,'Can delete email template',38,'delete_emailtemplate'),(152,'Can view email template',38,'view_emailtemplate'),(153,'Can add email log',39,'add_emaillog'),(154,'Can change email log',39,'change_emaillog'),(155,'Can delete email log',39,'delete_emaillog'),(156,'Can view email log',39,'view_emaillog'),(157,'Can add Block List Entry',40,'add_blocklist'),(158,'Can change Block List Entry',40,'change_blocklist'),(159,'Can delete Block List Entry',40,'delete_blocklist'),(160,'Can view Block List Entry',40,'view_blocklist'),(161,'Can add Curier',41,'add_curier'),(162,'Can change Curier',41,'change_curier'),(163,'Can delete Curier',41,'delete_curier'),(164,'Can view Curier',41,'view_curier'),(165,'Can add Checkout Customization',42,'add_checkoutcustomization'),(166,'Can change Checkout Customization',42,'change_checkoutcustomization'),(167,'Can delete Checkout Customization',42,'delete_checkoutcustomization'),(168,'Can view Checkout Customization',42,'view_checkoutcustomization'),(169,'Can add Site Settings',43,'add_sitesettings'),(170,'Can change Site Settings',43,'change_sitesettings'),(171,'Can delete Site Settings',43,'delete_sitesettings'),(172,'Can view Site Settings',43,'view_sitesettings'),(173,'Can add Integration Settings',44,'add_integrationsettings'),(174,'Can change Integration Settings',44,'change_integrationsettings'),(175,'Can delete Integration Settings',44,'delete_integrationsettings'),(176,'Can view Integration Settings',44,'view_integrationsettings'),(177,'Can add Hero Content',45,'add_herocontent'),(178,'Can change Hero Content',45,'change_herocontent'),(179,'Can delete Hero Content',45,'delete_herocontent'),(180,'Can view Hero Content',45,'view_herocontent'),(181,'Can add Stock Activity Batch',46,'add_stockactivitybatch'),(182,'Can change Stock Activity Batch',46,'change_stockactivitybatch'),(183,'Can delete Stock Activity Batch',46,'delete_stockactivitybatch'),(184,'Can view Stock Activity Batch',46,'view_stockactivitybatch'),(185,'Can add Stock Activity',47,'add_stockactivity'),(186,'Can change Stock Activity',47,'change_stockactivity'),(187,'Can delete Stock Activity',47,'delete_stockactivity'),(188,'Can view Stock Activity',47,'view_stockactivity'),(189,'Can add Page Category',48,'add_pagecategory'),(190,'Can change Page Category',48,'change_pagecategory'),(191,'Can delete Page Category',48,'delete_pagecategory'),(192,'Can view Page Category',48,'view_pagecategory'),(193,'Can add Page Template',49,'add_pagetemplate'),(194,'Can change Page Template',49,'change_pagetemplate'),(195,'Can delete Page Template',49,'delete_pagetemplate'),(196,'Can view Page Template',49,'view_pagetemplate'),(197,'Can add Page',50,'add_page'),(198,'Can change Page',50,'change_page'),(199,'Can delete Page',50,'delete_page'),(200,'Can view Page',50,'view_page'),(201,'Can add Page Media',51,'add_pagemedia'),(202,'Can change Page Media',51,'change_pagemedia'),(203,'Can delete Page Media',51,'delete_pagemedia'),(204,'Can view Page Media',51,'view_pagemedia'),(205,'Can add Page Revision',52,'add_pagerevision'),(206,'Can change Page Revision',52,'change_pagerevision'),(207,'Can delete Page Revision',52,'delete_pagerevision'),(208,'Can view Page Revision',52,'view_pagerevision'),(209,'Can add Page Analytics',53,'add_pageanalytics'),(210,'Can change Page Analytics',53,'change_pageanalytics'),(211,'Can delete Page Analytics',53,'delete_pageanalytics'),(212,'Can view Page Analytics',53,'view_pageanalytics'),(213,'Can add Contact Setting',54,'add_contactsetting'),(214,'Can change Contact Setting',54,'change_contactsetting'),(215,'Can delete Contact Setting',54,'delete_contactsetting'),(216,'Can view Contact Setting',54,'view_contactsetting'),(217,'Can add Contact Submission',55,'add_contact'),(218,'Can change Contact Submission',55,'change_contact'),(219,'Can delete Contact Submission',55,'delete_contact'),(220,'Can view Contact Submission',55,'view_contact'),(221,'Can add Contact Activity',56,'add_contactactivity'),(222,'Can change Contact Activity',56,'change_contactactivity'),(223,'Can delete Contact Activity',56,'delete_contactactivity'),(224,'Can view Contact Activity',56,'view_contactactivity'),(225,'Can add Backup Settings',57,'add_backupsettings'),(226,'Can change Backup Settings',57,'change_backupsettings'),(227,'Can delete Backup Settings',57,'delete_backupsettings'),(228,'Can view Backup Settings',57,'view_backupsettings'),(229,'Can add Backup Schedule',58,'add_backupschedule'),(230,'Can change Backup Schedule',58,'change_backupschedule'),(231,'Can delete Backup Schedule',58,'delete_backupschedule'),(232,'Can view Backup Schedule',58,'view_backupschedule'),(233,'Can add Restore Record',59,'add_restorerecord'),(234,'Can change Restore Record',59,'change_restorerecord'),(235,'Can delete Restore Record',59,'delete_restorerecord'),(236,'Can view Restore Record',59,'view_restorerecord'),(237,'Can add Backup Record',60,'add_backuprecord'),(238,'Can change Backup Record',60,'change_backuprecord'),(239,'Can delete Backup Record',60,'delete_backuprecord'),(240,'Can view Backup Record',60,'view_backuprecord');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `backup_type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `database_file` varchar(500) DEFAULT NULL,
  `media_file` varchar(500) DEFAULT NULL,
  `file_size` bigint NOT NULL,
  `database_size` bigint NOT NULL,
  `media_size` bigint NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `description` longtext NOT NULL,
  `error_message` longtext NOT NULL,
  `compress` tinyint(1) NOT NULL,
  `exclude_logs` tinyint(1) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_records_created_by_id_104a565b_fk_users_user_id` (`created_by_id`),
  CONSTRAINT `backup_records_created_by_id_104a565b_fk_users_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `backup_records` VALUES (11,'1111111111','full','in_progress',NULL,NULL,0,0,0,'2025-11-15 19:28:04.690531','2025-11-15 19:28:04.704545',NULL,'','',1,1,1);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_schedules` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `backup_type` varchar(20) NOT NULL,
  `schedule_type` varchar(20) NOT NULL,
  `hour` int unsigned NOT NULL,
  `minute` int unsigned NOT NULL,
  `day_of_week` int unsigned DEFAULT NULL,
  `day_of_month` int unsigned DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `compress` tinyint(1) NOT NULL,
  `exclude_logs` tinyint(1) NOT NULL,
  `retention_days` int unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `last_run` datetime(6) DEFAULT NULL,
  `next_run` datetime(6) DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `backup_schedules_created_by_id_f7b09f99_fk_users_user_id` (`created_by_id`),
  CONSTRAINT `backup_schedules_created_by_id_f7b09f99_fk_users_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `backup_schedules_chk_1` CHECK ((`hour` >= 0)),
  CONSTRAINT `backup_schedules_chk_2` CHECK ((`minute` >= 0)),
  CONSTRAINT `backup_schedules_chk_3` CHECK ((`day_of_week` >= 0)),
  CONSTRAINT `backup_schedules_chk_4` CHECK ((`day_of_month` >= 0)),
  CONSTRAINT `backup_schedules_chk_5` CHECK ((`retention_days` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_settings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `backup_directory` varchar(500) NOT NULL,
  `max_backup_size` bigint NOT NULL,
  `mysql_path` varchar(500) NOT NULL,
  `mysql_host` varchar(255) NOT NULL,
  `mysql_port` int unsigned NOT NULL,
  `mysql_user` varchar(255) NOT NULL,
  `mysql_password` varchar(255) NOT NULL,
  `mysql_database` varchar(255) NOT NULL,
  `compression_level` int unsigned NOT NULL,
  `default_retention_days` int unsigned NOT NULL,
  `auto_cleanup` tinyint(1) NOT NULL,
  `email_notifications` tinyint(1) NOT NULL,
  `notification_email` varchar(254) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `backup_settings_chk_1` CHECK ((`mysql_port` >= 0)),
  CONSTRAINT `backup_settings_chk_2` CHECK ((`compression_level` >= 0)),
  CONSTRAINT `backup_settings_chk_3` CHECK ((`default_retention_days` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `backup_settings` VALUES (1,'backups/',1073741824,'mysqldump','localhost',3306,'','','',6,30,1,0,'','2025-11-15 18:20:59.526626','2025-11-15 18:20:59.526626');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_cart` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `session_id` varchar(100) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `cart_cart_user_id_9b4220b9_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `cart_cart` VALUES (1,'rjt6kblg1neq4sw3sdo3zzj0soh5p63b','2025-11-14 18:54:24.783396','2025-11-14 18:54:24.783396',NULL),(2,'ozt0w9x8me19rgy6y3jhftkthlw3ue85','2025-11-14 18:54:24.783396','2025-11-14 18:54:24.783396',NULL),(3,'wmsy6ntgtwd3m7p1fsv0jx2umw0o98bn','2025-11-14 18:54:24.783396','2025-11-14 18:54:24.783396',NULL),(4,'p32th6gslxmipa1o9goc1cr6ye42q035','2025-11-14 18:54:24.816023','2025-11-14 18:54:24.816023',NULL),(5,'9exc8lmt76tbxzy10y9hvu6yv6qssccp','2025-11-14 18:54:24.865199','2025-11-14 18:54:24.865199',NULL),(6,NULL,'2025-11-14 19:06:27.733660','2025-11-14 19:06:27.733660',1),(7,'1c69v6s3ybietlhb2f7d4z40h9g8016s','2025-11-15 18:07:09.468910','2025-11-15 18:07:09.468910',NULL),(8,'m6ovod0gkbybq87qal846zl0acyvbgko','2025-11-15 18:07:09.471913','2025-11-15 18:07:09.471913',NULL),(9,'dvxp5w9aqz1742ws9u1ymj1z2nheh81l','2025-11-15 18:20:08.205153','2025-11-15 18:20:08.205153',NULL),(10,'zldak0486zm83o4669syeydxn03pk2f3','2025-11-15 18:20:08.208527','2025-11-15 18:20:08.209529',NULL),(11,'bsc5i12ayqm473hdzqd4pvun82ykmwuj','2025-11-15 19:04:12.848647','2025-11-15 19:04:12.848647',NULL),(12,'ag0lv7psmlj4g3ba4a7w05d0m0d4lzhq','2025-11-15 19:04:12.848647','2025-11-15 19:04:12.848647',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_cartitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int unsigned NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `cart_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `variant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cart_cartitem_cart_id_product_id_variant_id_5fc0c5f3_uniq` (`cart_id`,`product_id`,`variant_id`),
  KEY `cart_cartitem_product_id_b24e265a_fk_products_product_id` (`product_id`),
  KEY `cart_cartitem_variant_id_69f5d8c8_fk_products_productvariant_id` (`variant_id`),
  CONSTRAINT `cart_cartitem_cart_id_370ad265_fk_cart_cart_id` FOREIGN KEY (`cart_id`) REFERENCES `cart_cart` (`id`),
  CONSTRAINT `cart_cartitem_product_id_b24e265a_fk_products_product_id` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `cart_cartitem_variant_id_69f5d8c8_fk_products_productvariant_id` FOREIGN KEY (`variant_id`) REFERENCES `products_productvariant` (`id`),
  CONSTRAINT `cart_cartitem_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_coupon` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `discount_type` varchar(15) NOT NULL,
  `discount_value` decimal(10,2) NOT NULL,
  `minimum_order_amount` decimal(10,2) NOT NULL,
  `maximum_discount_amount` decimal(10,2) DEFAULT NULL,
  `usage_limit` int unsigned DEFAULT NULL,
  `usage_limit_per_user` int unsigned NOT NULL,
  `used_count` int unsigned NOT NULL,
  `valid_from` datetime(6) NOT NULL,
  `valid_until` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `cart_coupon_created_by_id_4ec3a747_fk_users_user_id` (`created_by_id`),
  KEY `cart_coupon_code_546127_idx` (`code`),
  KEY `cart_coupon_is_acti_bcae0d_idx` (`is_active`,`valid_from`,`valid_until`),
  CONSTRAINT `cart_coupon_created_by_id_4ec3a747_fk_users_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `cart_coupon_chk_1` CHECK ((`usage_limit` >= 0)),
  CONSTRAINT `cart_coupon_chk_2` CHECK ((`usage_limit_per_user` >= 0)),
  CONSTRAINT `cart_coupon_chk_3` CHECK ((`used_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_couponusage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` varchar(100) NOT NULL,
  `used_at` datetime(6) NOT NULL,
  `coupon_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `guest_email` varchar(254) NOT NULL,
  `guest_phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cart_couponusage_coupon_id_779347e1` (`coupon_id`),
  KEY `cart_couponusage_user_id_d873471b_fk_users_user_id` (`user_id`),
  KEY `cart_coupon_coupon__88b805_idx` (`coupon_id`,`user_id`,`order_id`),
  KEY `cart_coupon_coupon__3e30d6_idx` (`coupon_id`,`guest_email`,`order_id`),
  CONSTRAINT `cart_couponusage_coupon_id_779347e1_fk_cart_coupon_id` FOREIGN KEY (`coupon_id`) REFERENCES `cart_coupon` (`id`),
  CONSTRAINT `cart_couponusage_user_id_d873471b_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart_saveditem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int unsigned NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  `variant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cart_saveditem_user_id_product_id_variant_id_0c25ead8_uniq` (`user_id`,`product_id`,`variant_id`),
  KEY `cart_saveditem_product_id_8cbf1577_fk_products_product_id` (`product_id`),
  KEY `cart_saveditem_variant_id_1d5dfc2f_fk_products_productvariant_id` (`variant_id`),
  CONSTRAINT `cart_saveditem_product_id_8cbf1577_fk_products_product_id` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `cart_saveditem_user_id_65e1c7fa_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `cart_saveditem_variant_id_1d5dfc2f_fk_products_productvariant_id` FOREIGN KEY (`variant_id`) REFERENCES `products_productvariant` (`id`),
  CONSTRAINT `cart_saveditem_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(254) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `message` longtext NOT NULL,
  `attachment` varchar(100) DEFAULT NULL,
  `status` varchar(10) NOT NULL,
  `priority` varchar(10) NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `user_agent` longtext NOT NULL,
  `admin_notes` longtext NOT NULL,
  `submitted_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `replied_at` datetime(6) DEFAULT NULL,
  `assigned_to_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contact_con_status_f54a45_idx` (`status`,`submitted_at` DESC),
  KEY `contact_con_priorit_59f1cd_idx` (`priority`,`submitted_at` DESC),
  KEY `contact_con_email_bd0741_idx` (`email`,`submitted_at` DESC),
  KEY `contact_contact_assigned_to_id_5b7e0b30_fk_users_user_id` (`assigned_to_id`),
  CONSTRAINT `contact_contact_assigned_to_id_5b7e0b30_fk_users_user_id` FOREIGN KEY (`assigned_to_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_contactactivity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `user_agent` longtext,
  `timestamp` datetime(6) NOT NULL,
  `contact_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `contact_contactactiv_contact_id_acf3b57e_fk_contact_c` (`contact_id`),
  KEY `contact_contactactivity_user_id_1ac7981c_fk_users_user_id` (`user_id`),
  CONSTRAINT `contact_contactactiv_contact_id_acf3b57e_fk_contact_c` FOREIGN KEY (`contact_id`) REFERENCES `contact_contact` (`id`),
  CONSTRAINT `contact_contactactivity_user_id_1ac7981c_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_contactsetting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` json NOT NULL,
  `description` longtext,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_adminactivity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action` varchar(255) NOT NULL,
  `model_name` varchar(100) NOT NULL,
  `object_id` int unsigned DEFAULT NULL,
  `object_repr` varchar(255) NOT NULL,
  `changes` json DEFAULT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `user_agent` longtext,
  `timestamp` datetime(6) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_adminactivity_user_id_7ced8f2a_fk_users_user_id` (`user_id`),
  CONSTRAINT `dashboard_adminactivity_user_id_7ced8f2a_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `dashboard_adminactivity_chk_1` CHECK ((`object_id` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `dashboard_adminactivity` VALUES (1,'created','Category',1,'Short Wallet','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-14 19:12:01.875386',1),(2,'created','Product',1,'One Part Leather Luxury Wallet','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-14 19:13:21.335649',1),(3,'created','ProductImage',1,'Image for One Part Leather Luxury Wallet','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-14 19:13:55.579690',1),(4,'updated','Product',1,'One Part Leather Luxury Wallet','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-14 19:13:57.752718',1),(5,'created','ProductImage',2,'Image for One Part Leather Luxury Wallet','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-14 19:14:31.845582',1),(6,'created','ProductImage',3,'Image for One Part Leather Luxury Wallet','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-14 19:14:31.852030',1),(7,'created','ProductImage',4,'Image for One Part Leather Luxury Wallet','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-14 19:14:31.879068',1),(8,'updated','Product',1,'One Part Leather Luxury Wallet','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-14 19:14:33.592673',1),(9,'updated','User',1,'admin','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-15 16:45:56.513508',1),(10,'updated','User',1,'admin','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-15 16:45:56.542534',1),(11,'bulk_updated_checkout_customization','CheckoutCustomization',1,'Checkout Customization (Updated: 2025-11-15 16:56)','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-15 16:56:53.044378',1),(12,'updated_integration_settings','IntegrationSettings',1,'Integration Settings','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-15 17:10:46.865998',1),(13,'cloned','Product',2,'One Part Leather Luxury Wallet (Copy)','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-15 17:12:06.202646',1),(14,'updated','Product',2,'One Part Leather Luxury Wallet (Copy)','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-15 17:12:15.514935',1),(15,'updated','Product',2,'One Part Leather Luxury Wallet (Copy)','{}','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36','2025-11-15 17:12:24.747443',1);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_blocklist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `block_type` varchar(10) NOT NULL,
  `value` varchar(255) NOT NULL,
  `reason` varchar(20) NOT NULL,
  `description` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `block_count` int unsigned NOT NULL,
  `last_triggered` datetime(6) DEFAULT NULL,
  `blocked_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `dashboard_blocklist_block_type_value_48fe36bb_uniq` (`block_type`,`value`),
  KEY `dashboard_blocklist_blocked_by_id_a0093c10_fk_users_user_id` (`blocked_by_id`),
  KEY `dashboard_b_block_t_b34223_idx` (`block_type`,`value`),
  KEY `dashboard_b_is_acti_981190_idx` (`is_active`,`created_at` DESC),
  KEY `dashboard_b_reason_7a7bc2_idx` (`reason`,`created_at` DESC),
  CONSTRAINT `dashboard_blocklist_blocked_by_id_a0093c10_fk_users_user_id` FOREIGN KEY (`blocked_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `dashboard_blocklist_chk_1` CHECK ((`block_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_dashboardsetting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `key` varchar(100) NOT NULL,
  `value` json NOT NULL,
  `description` longtext,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_emailconfiguration` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `smtp_type` varchar(20) NOT NULL,
  `smtp_host` varchar(255) NOT NULL,
  `smtp_port` int NOT NULL,
  `smtp_use_tls` tinyint(1) NOT NULL,
  `smtp_use_ssl` tinyint(1) NOT NULL,
  `smtp_username` varchar(255) NOT NULL,
  `smtp_password` varchar(255) NOT NULL,
  `from_email` varchar(254) NOT NULL,
  `from_name` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_verified` tinyint(1) NOT NULL,
  `test_email_sent` tinyint(1) NOT NULL,
  `last_test_date` datetime(6) DEFAULT NULL,
  `test_result` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_emaillog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `recipient_email` varchar(254) NOT NULL,
  `sender_email` varchar(254) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `status` varchar(10) NOT NULL,
  `error_message` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `sent_at` datetime(6) DEFAULT NULL,
  `email_config_id` bigint DEFAULT NULL,
  `order_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `template_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_emaillog_email_config_id_9971008c_fk_dashboard` (`email_config_id`),
  KEY `dashboard_emaillog_order_id_7360c021_fk_orders_order_id` (`order_id`),
  KEY `dashboard_emaillog_user_id_87b768ee_fk_users_user_id` (`user_id`),
  KEY `dashboard_emaillog_template_id_1eaa6cf2_fk_dashboard` (`template_id`),
  KEY `dashboard_e_recipie_a0c311_idx` (`recipient_email`,`created_at` DESC),
  KEY `dashboard_e_status_b4961f_idx` (`status`,`created_at` DESC),
  CONSTRAINT `dashboard_emaillog_email_config_id_9971008c_fk_dashboard` FOREIGN KEY (`email_config_id`) REFERENCES `dashboard_emailconfiguration` (`id`),
  CONSTRAINT `dashboard_emaillog_order_id_7360c021_fk_orders_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders_order` (`id`),
  CONSTRAINT `dashboard_emaillog_template_id_1eaa6cf2_fk_dashboard` FOREIGN KEY (`template_id`) REFERENCES `dashboard_emailtemplate` (`id`),
  CONSTRAINT `dashboard_emaillog_user_id_87b768ee_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_emailtemplate` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `template_type` varchar(20) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `html_content` longtext NOT NULL,
  `text_content` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `send_to_user_email` tinyint(1) NOT NULL,
  `send_to_checkout_email` tinyint(1) NOT NULL,
  `available_variables` longtext NOT NULL,
  `description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_type` (`template_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_expense` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `expense_type` varchar(20) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `description` longtext,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `created_by_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_expense_created_by_id_e106da9e_fk_users_user_id` (`created_by_id`),
  CONSTRAINT `dashboard_expense_created_by_id_e106da9e_fk_users_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_users_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `django_admin_log` VALUES (1,'2025-11-15 16:47:00.895318','1','Profile for admin',1,'[{\"added\": {}}]',7,1);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(60,'backup','backuprecord'),(58,'backup','backupschedule'),(57,'backup','backupsettings'),(59,'backup','restorerecord'),(17,'cart','cart'),(18,'cart','cartitem'),(19,'cart','coupon'),(20,'cart','couponusage'),(21,'cart','saveditem'),(55,'contact','contact'),(56,'contact','contactactivity'),(54,'contact','contactsetting'),(4,'contenttypes','contenttype'),(35,'dashboard','adminactivity'),(40,'dashboard','blocklist'),(34,'dashboard','dashboardsetting'),(37,'dashboard','emailconfiguration'),(39,'dashboard','emaillog'),(38,'dashboard','emailtemplate'),(36,'dashboard','expense'),(29,'incomplete_orders','incompleteorder'),(28,'incomplete_orders','incompleteorderanalytics'),(30,'incomplete_orders','incompleteorderhistory'),(31,'incomplete_orders','incompleteorderitem'),(32,'incomplete_orders','incompleteshippingaddress'),(33,'incomplete_orders','recoveryemaillog'),(47,'inventory','stockactivity'),(46,'inventory','stockactivitybatch'),(22,'orders','invoice'),(23,'orders','order'),(24,'orders','orderitem'),(25,'orders','orderstatushistory'),(27,'orders','refundrequest'),(26,'orders','shippingaddress'),(50,'pages','page'),(53,'pages','pageanalytics'),(48,'pages','pagecategory'),(51,'pages','pagemedia'),(52,'pages','pagerevision'),(49,'pages','pagetemplate'),(10,'products','category'),(11,'products','product'),(12,'products','productimage'),(13,'products','productvariant'),(14,'products','review'),(16,'products','reviewimage'),(15,'products','wishlist'),(5,'sessions','session'),(42,'settings','checkoutcustomization'),(41,'settings','curier'),(45,'settings','herocontent'),(44,'settings','integrationsettings'),(43,'settings','sitesettings'),(8,'users','address'),(9,'users','dashboardpermission'),(6,'users','user'),(7,'users','userprofile');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2025-11-14 18:53:34.685759'),(2,'contenttypes','0002_remove_content_type_name','2025-11-14 18:53:35.290536'),(3,'auth','0001_initial','2025-11-14 18:53:36.378817'),(4,'auth','0002_alter_permission_name_max_length','2025-11-14 18:53:36.486083'),(5,'auth','0003_alter_user_email_max_length','2025-11-14 18:53:36.493317'),(6,'auth','0004_alter_user_username_opts','2025-11-14 18:53:36.500326'),(7,'auth','0005_alter_user_last_login_null','2025-11-14 18:53:36.508273'),(8,'auth','0006_require_contenttypes_0002','2025-11-14 18:53:36.512832'),(9,'auth','0007_alter_validators_add_error_messages','2025-11-14 18:53:36.520201'),(10,'auth','0008_alter_user_username_max_length','2025-11-14 18:53:36.529207'),(11,'auth','0009_alter_user_last_name_max_length','2025-11-14 18:53:36.536797'),(12,'auth','0010_alter_group_name_max_length','2025-11-14 18:53:36.559978'),(13,'auth','0011_update_proxy_permissions','2025-11-14 18:53:36.568493'),(14,'auth','0012_alter_user_first_name_max_length','2025-11-14 18:53:36.575271'),(15,'users','0001_initial','2025-11-14 18:53:37.423107'),(16,'admin','0001_initial','2025-11-14 18:53:37.990584'),(17,'admin','0002_logentry_remove_auto_add','2025-11-14 18:53:38.013787'),(18,'admin','0003_logentry_add_action_flag_choices','2025-11-14 18:53:38.051095'),(19,'products','0001_initial','2025-11-14 18:53:38.619111'),(20,'cart','0001_initial','2025-11-14 18:53:38.840286'),(21,'cart','0002_initial','2025-11-14 18:53:38.941888'),(22,'cart','0003_initial','2025-11-14 18:53:40.318771'),(23,'cart','0004_alter_coupon_options_coupon_created_by_and_more','2025-11-14 18:53:40.633498'),(24,'cart','0005_alter_couponusage_unique_together_and_more','2025-11-14 18:53:41.196931'),(25,'contact','0001_initial','2025-11-14 18:53:41.933228'),(26,'orders','0001_initial','2025-11-14 18:53:42.484421'),(27,'orders','0002_initial','2025-11-14 18:53:44.012540'),(28,'orders','0003_order_guest_email_order_is_guest_order_and_more','2025-11-14 18:53:45.108000'),(29,'orders','0004_enhance_order_tracking','2025-11-14 18:53:46.136178'),(30,'orders','0005_order_curier_charge_order_curier_id_and_more','2025-11-14 18:53:46.669480'),(31,'orders','0006_add_cost_price_field','2025-11-14 18:53:46.990247'),(32,'orders','0007_alter_shippingaddress_last_name','2025-11-14 18:53:47.004297'),(33,'orders','0002_order_send_curier','2025-11-14 18:53:47.261837'),(34,'orders','0008_merge_20250919_0036','2025-11-14 18:53:47.267049'),(35,'orders','0009_remove_order_send_curier','2025-11-14 18:53:47.382709'),(36,'orders','0010_order_curier_date','2025-11-14 18:53:47.519194'),(37,'orders','0011_order_bkash_sender_number_order_bkash_transaction_id_and_more','2025-11-14 18:53:49.428165'),(38,'orders','0012_alter_order_status_alter_orderstatushistory_status','2025-11-14 18:53:49.467834'),(39,'dashboard','0001_initial','2025-11-14 18:53:49.682595'),(40,'dashboard','0002_expense','2025-11-14 18:53:49.872131'),(41,'dashboard','0003_emailconfiguration_emailtemplate_emaillog','2025-11-14 18:53:50.534305'),(42,'dashboard','0004_blocklist','2025-11-14 18:53:50.797514'),(43,'products','0002_initial','2025-11-14 18:53:52.115948'),(44,'products','0003_productvariant_image','2025-11-14 18:53:52.303560'),(45,'products','0004_auto_20250725_0022','2025-11-14 18:53:52.310565'),(46,'products','0005_product_custom_express_shipping_and_more','2025-11-14 18:53:53.076844'),(47,'products','0006_product_has_express_shipping_and_more','2025-11-14 18:53:53.313442'),(48,'products','0007_productvariant_is_default_and_more','2025-11-14 18:53:53.466189'),(49,'products','0008_auto_20250728_0126','2025-11-14 18:53:53.508310'),(50,'products','0009_product_youtube_video_url','2025-11-14 18:53:53.726023'),(51,'products','0010_reviewimage_alter_review_unique_together_and_more','2025-11-14 18:53:54.620739'),(52,'products','0011_alter_review_is_approved','2025-11-14 18:53:54.650386'),(53,'products','0012_productvariant_in_stock','2025-11-14 18:53:54.782425'),(54,'products','0013_productvariant_compare_price_and_more','2025-11-14 18:53:54.996799'),(55,'products','0014_product_in_stock','2025-11-14 18:53:55.150894'),(56,'incomplete_orders','0001_initial','2025-11-14 18:53:56.825190'),(57,'inventory','0001_initial','2025-11-14 18:53:57.885207'),(58,'orders','0013_order_customer_ip','2025-11-14 18:53:58.053671'),(59,'orders','0014_order_coupon_alter_order_coupon_code_and_more','2025-11-14 18:53:58.365172'),(60,'pages','0001_initial','2025-11-14 18:54:01.912621'),(61,'pages','0002_alter_page_content','2025-11-14 18:54:01.952817'),(62,'pages','0003_remove_page_allow_comments_delete_pagecomment','2025-11-14 18:54:02.182891'),(63,'products','0015_change_productimage_to_url','2025-11-14 18:54:02.225329'),(64,'products','0016_change_variant_image_to_url','2025-11-14 18:54:02.280187'),(65,'products','0017_alter_productimage_image_alter_productvariant_image','2025-11-14 18:54:02.310143'),(66,'products','0018_change_category_image_to_textfield','2025-11-14 18:54:02.450262'),(67,'sessions','0001_initial','2025-11-14 18:54:02.517766'),(68,'settings','0001_initial','2025-11-14 18:54:02.970688'),(69,'settings','0002_auto_20250917_2309','2025-11-14 18:54:02.974186'),(70,'settings','0003_checkoutcustomization','2025-11-14 18:54:03.040261'),(71,'settings','0004_sitesettings','2025-11-14 18:54:03.097877'),(72,'settings','0005_alter_sitesettings_footer_logo_and_more','2025-11-14 18:54:03.178122'),(73,'settings','0006_integrationsettings','2025-11-14 18:54:03.275321'),(74,'settings','0007_herocontent','2025-11-14 18:54:03.341916'),(75,'settings','0008_sitesettings_delivery_time_max_and_more','2025-11-14 18:54:04.948054'),(76,'settings','0009_remove_unused_shipping_fields','2025-11-14 18:54:05.752489'),(77,'settings','0010_sitesettings_custom_today_date_and_more','2025-11-14 18:54:06.618820'),(78,'users','0002_add_email_verification_fields','2025-11-14 18:54:08.650665'),(79,'users','0003_dashboardpermission','2025-11-14 18:54:08.842557'),(80,'users','0004_alter_user_managers','2025-11-14 19:21:36.360865'),(81,'backup','0001_initial','2025-11-15 18:20:50.364792');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `django_session` VALUES ('1c69v6s3ybietlhb2f7d4z40h9g8016s','e30:1vKKg1:2OQq1fdBthy0sZuO11p-Q_872X_xP-T4Kqcs6qba97o','2025-11-29 18:07:09.488929'),('6y2cie4uay3whdra82ythdnz8blvb5ei','.eJxVjMsKwjAQRf8layl5NLG6FPoLbstMZoYENUKTrsR_10AXurznXM5LLbC1tGyV1yWTOiujDr8MId64dNFnHbrh0nKElp9lmB-Q71des-zksv__Iglq-ha0sY5Qk0cWCEYjuEie2U4gJN67wEcxhsMoTBjGSQchOzqDJyTrRb0_XQs7Hg:1vKLfs:DPBjPHgcwNyX67I2-rI1KxOvlFFTshs3M5H-_BTIyFY','2025-11-29 19:11:04.718508'),('94dt6oqm13j76am7470ysyw8ks9yiooq','.eJxVjMsKwjAQRf8layl5NLG6FPoLbstMZoYENUKTrsR_10AXurznXM5LLbC1tGyV1yWTOiujDr8MId64dNFnHbrh0nKElp9lmB-Q71des-zksv__Iglq-ha0sY5Qk0cWCEYjuEie2U4gJN67wEcxhsMoTBjGSQchOzqDJyTrRb0_XQs7Hg:1vKLgR:vrmrM24ZLv3oqN9Vzggx8PiCibT7qv72rD-wbZcWcZE','2025-11-29 19:11:39.363093'),('ag0lv7psmlj4g3ba4a7w05d0m0d4lzhq','e30:1vKLZE:ApwoFV6CBYw-e2pYxQQcS7QjoLI9W-cVnfVmtIs-W3c','2025-11-29 19:04:12.905207'),('c26a8x6yyeqxkquh28l7fvym2c6povo4','.eJxVjMsKwjAQRf8layl5NLG6FPoLbstMZoYENUKTrsR_10AXurznXM5LLbC1tGyV1yWTOiujDr8MId64dNFnHbrh0nKElp9lmB-Q71des-zksv__Iglq-ha0sY5Qk0cWCEYjuEie2U4gJN67wEcxhsMoTBjGSQchOzqDJyTrRb0_XQs7Hg:1vKLdp:dgU7f8ZMPWvEvJ4YEQ49Nj7-Y_bu56gOA1x_B3EnDYw','2025-11-29 19:08:57.521864'),('cvzkg9c3srfc0qz921ongl0a7uyxu6qa','.eJxVjMsKwjAQRf8layl5NLG6FPoLbstMZoYENUKTrsR_10AXurznXM5LLbC1tGyV1yWTOiujDr8MId64dNFnHbrh0nKElp9lmB-Q71des-zksv__Iglq-ha0sY5Qk0cWCEYjuEie2U4gJN67wEcxhsMoTBjGSQchOzqDJyTrRb0_XQs7Hg:1vKLkq:TpgkVBigIWB0ZasZJcu3jqSL2r_DDEf3pceIvMIYxfU','2025-11-29 19:16:12.066320'),('dvxp5w9aqz1742ws9u1ymj1z2nheh81l','e30:1vKKsa:CpG73wH-VwpE0k-BZthWLPDenR0lmZW2TJMHhC2dbE0','2025-11-29 18:20:08.224542'),('naywby7iwe83yybsgim1t76kh5uiqc8h','.eJxVjc0KwjAQhN8lZyn5aWLbo-AreA273V0a1FqaFhTx3W2gBz3ON8M3bxVhXYa4Zp5jItUpow6_DKG_8liKEnNVGh6X1MOSHmN1vkO6XXhOspPTvv-TDJCHzaCNdYSaPLJAMBrB9eSZbQNC4r0LfBRjONTChKFudBCytTPYIlkvRZo55-0m8nNK80t11rdWa_35AtZ_Q40:1vKKgA:zVAKV6fScHW1bO03r6fsiv0QHk7-Wy0l39QkuTjvTXo','2025-12-15 18:07:18.865919'),('nktozedt0fzu0gxmagqgd3fcp7d58tpz','.eJxVjMsKwjAQRf8layl5NLG6FPoLbstMZoYENUKTrsR_10AXurznXM5LLbC1tGyV1yWTOiujDr8MId64dNFnHbrh0nKElp9lmB-Q71des-zksv__Iglq-ha0sY5Qk0cWCEYjuEie2U4gJN67wEcxhsMoTBjGSQchOzqDJyTrRb0_XQs7Hg:1vKLk4:0fYinj9vRV0lzq4xamgENTCQWLNZedcXwWPTFE9k2YI','2025-11-29 19:15:24.396560'),('ozt0w9x8me19rgy6y3jhftkthlw3ue85','e30:1vJywC:plTyu_aug8XiIGdbHosL8CBNeAQQLGvtjiPiMQKIdF0','2025-11-28 18:54:24.879781'),('p32th6gslxmipa1o9goc1cr6ye42q035','e30:1vJywC:plTyu_aug8XiIGdbHosL8CBNeAQQLGvtjiPiMQKIdF0','2025-11-28 18:54:24.890298'),('pdt3cgr1o8eo0bg6jjd7j59j1k8luce1','.eJxVjc0KwjAQhN8lZyn5aWLbo-AreA273V0a1FqaFhTx3W2gBz3ON8M3bxVhXYa4Zp5jItUpow6_DKG_8liKEnNVGh6X1MOSHmN1vkO6XXhOspPTvv-TDJCHzaCNdYSaPLJAMBrB9eSZbQNC4r0LfBRjONTChKFudBCytTPYIlkvRZo55-0m8nNK80t11rdWa_35AtZ_Q40:1vKLZL:RiVMSRym-3FITaov-KPn8c1-CKiOTUj6bBif1P1gArw','2025-12-15 19:04:19.381159'),('rjt6kblg1neq4sw3sdo3zzj0soh5p63b','e30:1vJywC:plTyu_aug8XiIGdbHosL8CBNeAQQLGvtjiPiMQKIdF0','2025-11-28 18:54:24.877772'),('uzqgrmgv98b0brf13xwsyvm5xrs00w9d','.eJxVjc0KwjAQhN8lZyn5aWLtUfAVvIbd7i4NapWkBUV8dxvoQY_zzfDNW0VY5jEuhXNMpHpl1O6XIQwXnmpRY2lqw9OcBpjTfWpON0jXM-ckGzlu-z_JCGVcDdpYR6jJIwsEoxHcQJ7ZdiAk3rvAezGGQytMGNpOByHbOoMHJOulSguXst5Efj5Sfqlef75FuUJb:1vKKsg:v57ujziXsfVFPl479zPDD8xAa_gdZAQ8buNRhi9cu8A','2025-11-29 18:20:14.788132'),('vs4pcacrzk1fuxjqbcei01q4dkvsjc0a','.eJxVjMsKwjAQRf8layl5NLG6FPoLbstMZoYENUKTrsR_10AXurznXM5LLbC1tGyV1yWTOiujDr8MId64dNFnHbrh0nKElp9lmB-Q71des-zksv__Iglq-ha0sY5Qk0cWCEYjuEie2U4gJN67wEcxhsMoTBjGSQchOzqDJyTrRb0_XQs7Hg:1vKLf7:8w7LXi7OKOmWSTbiL1R0QL7d4DE-bNb9UBayiZDnDZA','2025-11-29 19:10:17.479402'),('wmsy6ntgtwd3m7p1fsv0jx2umw0o98bn','e30:1vJywC:plTyu_aug8XiIGdbHosL8CBNeAQQLGvtjiPiMQKIdF0','2025-11-28 18:54:24.876771'),('xl66wecrcbz1wjfxzbfy8ygy1b3n5h0g','.eJxVjMsKwjAQRf8layl5NLG6FPoLbstMZoYENUKTrsR_10AXurznXM5LLbC1tGyV1yWTOiujDr8MId64dNFnHbrh0nKElp9lmB-Q71des-zksv__Iglq-ha0sY5Qk0cWCEYjuEie2U4gJN67wEcxhsMoTBjGSQchOzqDJyTrRb0_XQs7Hg:1vKLdT:dh3QqPF2hUUQnaXAekXEhTTX21AAY354T69IV_W1kk4','2025-11-29 19:08:35.766454'),('y9foucjqy4c000ii0fh0aq6sn0qu9ke2','.eJxVjc0KwjAQhN8lZyn5aWLbo-AreA273V0a1FqaFhTx3W2gBz3ON8M3bxVhXYa4Zp5jItUpow6_DKG_8liKEnNVGh6X1MOSHmN1vkO6XXhOspPTvv-TDJCHzaCNdYSaPLJAMBrB9eSZbQNC4r0LfBRjONTChKFudBCytTPYIlkvRZo55-0m8nNK80t11rdWa_35AtZ_Q40:1vJz7r:UNhTCSmWxRoIaCU00y74cYeZgIAi2ad5WyUpErGiemU','2025-12-14 19:06:27.677368');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incomplete_orders_incompleteorder` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `incomplete_order_id` varchar(50) NOT NULL,
  `is_guest_order` tinyint(1) NOT NULL,
  `guest_email` varchar(254) NOT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `status` varchar(20) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `shipping_cost` decimal(8,2) NOT NULL,
  `tax_amount` decimal(8,2) NOT NULL,
  `discount_amount` decimal(8,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `coupon_code` varchar(50) NOT NULL,
  `coupon_discount` decimal(8,2) NOT NULL,
  `customer_email` varchar(254) NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  `recovery_attempts` int unsigned NOT NULL,
  `last_recovery_attempt` datetime(6) DEFAULT NULL,
  `user_agent` longtext NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `referrer_url` varchar(200) NOT NULL,
  `customer_notes` longtext NOT NULL,
  `admin_notes` longtext NOT NULL,
  `abandonment_reason` varchar(100) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `abandoned_at` datetime(6) DEFAULT NULL,
  `expires_at` datetime(6) DEFAULT NULL,
  `converted_order_id` varchar(50) NOT NULL,
  `converted_at` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `incomplete_order_id` (`incomplete_order_id`),
  KEY `incomplete__user_id_31e80c_idx` (`user_id`,`created_at` DESC),
  KEY `incomplete__status_b2e763_idx` (`status`),
  KEY `incomplete__session_2f49e0_idx` (`session_id`),
  KEY `incomplete__expires_70f9a0_idx` (`expires_at`),
  CONSTRAINT `incomplete_orders_in_user_id_bedf7743_fk_users_use` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `incomplete_orders_incompleteorder_chk_1` CHECK ((`recovery_attempts` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incomplete_orders_incompleteorderanalytics` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `total_incomplete_orders` int unsigned NOT NULL,
  `abandoned_orders` int unsigned NOT NULL,
  `converted_orders` int unsigned NOT NULL,
  `expired_orders` int unsigned NOT NULL,
  `recovery_emails_sent` int unsigned NOT NULL,
  `recovery_success_count` int unsigned NOT NULL,
  `total_lost_revenue` decimal(12,2) NOT NULL,
  `recovered_revenue` decimal(12,2) NOT NULL,
  `conversion_rate` decimal(5,2) NOT NULL,
  `recovery_rate` decimal(5,2) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `date` (`date`),
  CONSTRAINT `incomplete_orders_incompleteorderanalytics_chk_1` CHECK ((`total_incomplete_orders` >= 0)),
  CONSTRAINT `incomplete_orders_incompleteorderanalytics_chk_2` CHECK ((`abandoned_orders` >= 0)),
  CONSTRAINT `incomplete_orders_incompleteorderanalytics_chk_3` CHECK ((`converted_orders` >= 0)),
  CONSTRAINT `incomplete_orders_incompleteorderanalytics_chk_4` CHECK ((`expired_orders` >= 0)),
  CONSTRAINT `incomplete_orders_incompleteorderanalytics_chk_5` CHECK ((`recovery_emails_sent` >= 0)),
  CONSTRAINT `incomplete_orders_incompleteorderanalytics_chk_6` CHECK ((`recovery_success_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incomplete_orders_incompleteorderhistory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `action` varchar(20) NOT NULL,
  `details` longtext NOT NULL,
  `created_by_system` tinyint(1) NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `user_agent` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `incomplete_order_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `incomplete_orders_in_incomplete_order_id_29932a7e_fk_incomplet` (`incomplete_order_id`),
  KEY `incomplete_orders_in_user_id_23a1bcc3_fk_users_use` (`user_id`),
  CONSTRAINT `incomplete_orders_in_incomplete_order_id_29932a7e_fk_incomplet` FOREIGN KEY (`incomplete_order_id`) REFERENCES `incomplete_orders_incompleteorder` (`id`),
  CONSTRAINT `incomplete_orders_in_user_id_23a1bcc3_fk_users_use` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incomplete_orders_incompleteorderitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_name` varchar(200) NOT NULL,
  `product_sku` varchar(100) NOT NULL,
  `variant_name` varchar(100) NOT NULL,
  `quantity` int unsigned NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `added_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `incomplete_order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `variant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `incomplete_orders_in_incomplete_order_id_b31521d6_fk_incomplet` (`incomplete_order_id`),
  KEY `incomplete_orders_in_product_id_eeefe63c_fk_products_` (`product_id`),
  KEY `incomplete_orders_in_variant_id_3b153742_fk_products_` (`variant_id`),
  CONSTRAINT `incomplete_orders_in_incomplete_order_id_b31521d6_fk_incomplet` FOREIGN KEY (`incomplete_order_id`) REFERENCES `incomplete_orders_incompleteorder` (`id`),
  CONSTRAINT `incomplete_orders_in_product_id_eeefe63c_fk_products_` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `incomplete_orders_in_variant_id_3b153742_fk_products_` FOREIGN KEY (`variant_id`) REFERENCES `products_productvariant` (`id`),
  CONSTRAINT `incomplete_orders_incompleteorderitem_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incomplete_orders_incompleteshippingaddress` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `country` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(254) NOT NULL,
  `delivery_instructions` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `incomplete_order_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `incomplete_order_id` (`incomplete_order_id`),
  CONSTRAINT `incomplete_orders_in_incomplete_order_id_7514a4f0_fk_incomplet` FOREIGN KEY (`incomplete_order_id`) REFERENCES `incomplete_orders_incompleteorder` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incomplete_orders_recoveryemaillog` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_type` varchar(20) NOT NULL,
  `recipient_email` varchar(254) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `sent_at` datetime(6) NOT NULL,
  `delivered` tinyint(1) NOT NULL,
  `opened` tinyint(1) NOT NULL,
  `clicked` tinyint(1) NOT NULL,
  `responded` tinyint(1) NOT NULL,
  `response_date` datetime(6) DEFAULT NULL,
  `discount_code` varchar(50) NOT NULL,
  `discount_percentage` decimal(5,2) NOT NULL,
  `incomplete_order_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `incomplete_orders_re_incomplete_order_id_e61d6769_fk_incomplet` (`incomplete_order_id`),
  CONSTRAINT `incomplete_orders_re_incomplete_order_id_e61d6769_fk_incomplet` FOREIGN KEY (`incomplete_order_id`) REFERENCES `incomplete_orders_incompleteorder` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_stockactivity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `activity_type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `object_id` int unsigned NOT NULL,
  `quantity_before` int NOT NULL,
  `quantity_changed` int NOT NULL,
  `quantity_after` int NOT NULL,
  `unit_cost` decimal(10,2) DEFAULT NULL,
  `total_cost` decimal(10,2) DEFAULT NULL,
  `reason` longtext NOT NULL,
  `reference_number` varchar(100) NOT NULL,
  `notes` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `activity_date` datetime(6) NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `user_agent` longtext NOT NULL,
  `approved_by_id` bigint DEFAULT NULL,
  `content_type_id` int NOT NULL,
  `created_by_id` bigint NOT NULL,
  `batch_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_stockactivity_approved_by_id_5a3bc3e9_fk_users_user_id` (`approved_by_id`),
  KEY `inventory_stockactiv_batch_id_832be878_fk_inventory` (`batch_id`),
  KEY `inventory_s_content_12b990_idx` (`content_type_id`,`object_id`),
  KEY `inventory_s_activit_6d38db_idx` (`activity_type`),
  KEY `inventory_s_created_63340a_idx` (`created_by_id`),
  KEY `inventory_s_activit_abcf90_idx` (`activity_date`),
  KEY `inventory_s_status_a9d5cb_idx` (`status`),
  CONSTRAINT `inventory_stockactiv_batch_id_832be878_fk_inventory` FOREIGN KEY (`batch_id`) REFERENCES `inventory_stockactivitybatch` (`id`),
  CONSTRAINT `inventory_stockactiv_content_type_id_7ceb6693_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `inventory_stockactivity_approved_by_id_5a3bc3e9_fk_users_user_id` FOREIGN KEY (`approved_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `inventory_stockactivity_created_by_id_8d6509b9_fk_users_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `inventory_stockactivity_chk_1` CHECK ((`object_id` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_stockactivitybatch` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `batch_type` varchar(20) NOT NULL,
  `batch_number` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `total_activities` int unsigned NOT NULL,
  `completed_activities` int unsigned NOT NULL,
  `failed_activities` int unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `is_completed` tinyint(1) NOT NULL,
  `created_by_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `batch_number` (`batch_number`),
  KEY `inventory_stockactiv_created_by_id_55980607_fk_users_use` (`created_by_id`),
  CONSTRAINT `inventory_stockactiv_created_by_id_55980607_fk_users_use` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `inventory_stockactivitybatch_chk_1` CHECK ((`total_activities` >= 0)),
  CONSTRAINT `inventory_stockactivitybatch_chk_2` CHECK ((`completed_activities` >= 0)),
  CONSTRAINT `inventory_stockactivitybatch_chk_3` CHECK ((`failed_activities` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_invoice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `invoice_date` datetime(6) NOT NULL,
  `invoice_file` varchar(100) DEFAULT NULL,
  `billing_name` varchar(200) NOT NULL,
  `billing_email` varchar(254) NOT NULL,
  `billing_address` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `order_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoice_number` (`invoice_number`),
  UNIQUE KEY `order_id` (`order_id`),
  CONSTRAINT `orders_invoice_order_id_bc372e79_fk_orders_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `payment_status` varchar(20) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `shipping_cost` decimal(8,2) NOT NULL,
  `tax_amount` decimal(8,2) NOT NULL,
  `discount_amount` decimal(8,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `coupon_code` varchar(50) NOT NULL,
  `coupon_discount` decimal(8,2) NOT NULL,
  `customer_email` varchar(254) NOT NULL,
  `customer_phone` varchar(15) NOT NULL,
  `customer_notes` longtext NOT NULL,
  `admin_notes` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `confirmed_at` datetime(6) DEFAULT NULL,
  `shipped_at` datetime(6) DEFAULT NULL,
  `delivered_at` datetime(6) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  `guest_email` varchar(254) NOT NULL,
  `is_guest_order` tinyint(1) NOT NULL,
  `session_id` varchar(100) DEFAULT NULL,
  `curier_charge` decimal(8,2) NOT NULL,
  `curier_id` varchar(100) NOT NULL,
  `curier_status` varchar(100) NOT NULL,
  `cost_price` decimal(10,2) NOT NULL,
  `partially_ammount` decimal(10,2) NOT NULL,
  `curier_date` date DEFAULT NULL,
  `bkash_sender_number` varchar(15) NOT NULL,
  `bkash_transaction_id` varchar(100) NOT NULL,
  `nagad_sender_number` varchar(15) NOT NULL,
  `nagad_transaction_id` varchar(100) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `payment_method_display_name` varchar(100) NOT NULL,
  `customer_ip` char(39) DEFAULT NULL,
  `coupon_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_number` (`order_number`),
  KEY `orders_orde_user_id_0ae59f_idx` (`user_id`,`created_at` DESC),
  KEY `orders_orde_status_c6dd84_idx` (`status`),
  KEY `orders_orde_payment_bc131d_idx` (`payment_status`),
  KEY `orders_order_coupon_id_5bddb887_fk_cart_coupon_id` (`coupon_id`),
  CONSTRAINT `orders_order_coupon_id_5bddb887_fk_cart_coupon_id` FOREIGN KEY (`coupon_id`) REFERENCES `cart_coupon` (`id`),
  CONSTRAINT `orders_order_user_id_e9b59eb1_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_orderitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_name` varchar(200) NOT NULL,
  `product_sku` varchar(100) NOT NULL,
  `variant_name` varchar(100) NOT NULL,
  `quantity` int unsigned NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `order_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `variant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_orderitem_order_id_fe61a34d_fk_orders_order_id` (`order_id`),
  KEY `orders_orderitem_product_id_afe4254a_fk_products_product_id` (`product_id`),
  KEY `orders_orderitem_variant_id_5d350ded_fk_products_` (`variant_id`),
  CONSTRAINT `orders_orderitem_order_id_fe61a34d_fk_orders_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders_order` (`id`),
  CONSTRAINT `orders_orderitem_product_id_afe4254a_fk_products_product_id` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `orders_orderitem_variant_id_5d350ded_fk_products_` FOREIGN KEY (`variant_id`) REFERENCES `products_productvariant` (`id`),
  CONSTRAINT `orders_orderitem_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_orderstatushistory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `old_status` varchar(20) NOT NULL,
  `new_status` varchar(20) NOT NULL,
  `notes` longtext NOT NULL,
  `tracking_number` varchar(100) NOT NULL,
  `carrier` varchar(100) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `changed_by_id` bigint DEFAULT NULL,
  `order_id` bigint NOT NULL,
  `carrier_url` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `estimated_delivery` datetime(6) DEFAULT NULL,
  `is_customer_visible` tinyint(1) NOT NULL,
  `is_milestone` tinyint(1) NOT NULL,
  `is_system_generated` tinyint(1) NOT NULL,
  `location` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_orderstatushi_changed_by_id_d823a516_fk_users_use` (`changed_by_id`),
  KEY `orders_orderstatushistory_order_id_bf09a0e1_fk_orders_order_id` (`order_id`),
  CONSTRAINT `orders_orderstatushi_changed_by_id_d823a516_fk_users_use` FOREIGN KEY (`changed_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `orders_orderstatushistory_order_id_bf09a0e1_fk_orders_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_refundrequest` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `refund_amount` decimal(10,2) NOT NULL,
  `reason` varchar(20) NOT NULL,
  `description` longtext NOT NULL,
  `status` varchar(20) NOT NULL,
  `admin_response` longtext NOT NULL,
  `processed_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `order_id` bigint NOT NULL,
  `processed_by_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_refundrequest_order_id_395c6566_fk_orders_order_id` (`order_id`),
  KEY `orders_refundrequest_processed_by_id_9f3452ac_fk_users_user_id` (`processed_by_id`),
  KEY `orders_refundrequest_user_id_eafa212a_fk_users_user_id` (`user_id`),
  CONSTRAINT `orders_refundrequest_order_id_395c6566_fk_orders_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders_order` (`id`),
  CONSTRAINT `orders_refundrequest_processed_by_id_9f3452ac_fk_users_user_id` FOREIGN KEY (`processed_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `orders_refundrequest_user_id_eafa212a_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders_shippingaddress` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `company` varchar(100) NOT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `country` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `email` varchar(254) NOT NULL,
  `delivery_instructions` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `order_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_id` (`order_id`),
  CONSTRAINT `orders_shippingaddress_order_id_da2e8a03_fk_orders_order_id` FOREIGN KEY (`order_id`) REFERENCES `orders_order` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_page` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `excerpt` longtext NOT NULL,
  `featured_image` varchar(100) DEFAULT NULL,
  `featured_image_alt` varchar(200) NOT NULL,
  `meta_title` varchar(60) NOT NULL,
  `meta_description` varchar(160) NOT NULL,
  `meta_keywords` varchar(200) NOT NULL,
  `canonical_url` varchar(200) NOT NULL,
  `status` varchar(20) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `show_in_menu` tinyint(1) NOT NULL,
  `menu_order` int unsigned NOT NULL,
  `require_login` tinyint(1) NOT NULL,
  `publish_date` datetime(6) NOT NULL,
  `expiry_date` datetime(6) DEFAULT NULL,
  `view_count` int unsigned NOT NULL,
  `share_count` int unsigned NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `author_id` bigint NOT NULL,
  `last_modified_by_id` bigint DEFAULT NULL,
  `category_id` bigint DEFAULT NULL,
  `template_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `pages_page_slug_3e99a9_idx` (`slug`),
  KEY `pages_page_status_48717e_idx` (`status`),
  KEY `pages_page_publish_b99365_idx` (`publish_date`),
  KEY `pages_page_is_feat_6566a6_idx` (`is_featured`),
  KEY `pages_page_show_in_4abef8_idx` (`show_in_menu`),
  KEY `pages_page_author_id_fed45c98_fk_users_user_id` (`author_id`),
  KEY `pages_page_last_modified_by_id_9171b9ff_fk_users_user_id` (`last_modified_by_id`),
  KEY `pages_page_category_id_1ddf8d86_fk_pages_pagecategory_id` (`category_id`),
  KEY `pages_page_template_id_363e3c5b_fk_pages_pagetemplate_id` (`template_id`),
  CONSTRAINT `pages_page_author_id_fed45c98_fk_users_user_id` FOREIGN KEY (`author_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `pages_page_category_id_1ddf8d86_fk_pages_pagecategory_id` FOREIGN KEY (`category_id`) REFERENCES `pages_pagecategory` (`id`),
  CONSTRAINT `pages_page_last_modified_by_id_9171b9ff_fk_users_user_id` FOREIGN KEY (`last_modified_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `pages_page_template_id_363e3c5b_fk_pages_pagetemplate_id` FOREIGN KEY (`template_id`) REFERENCES `pages_pagetemplate` (`id`),
  CONSTRAINT `pages_page_chk_1` CHECK ((`menu_order` >= 0)),
  CONSTRAINT `pages_page_chk_2` CHECK ((`view_count` >= 0)),
  CONSTRAINT `pages_page_chk_3` CHECK ((`share_count` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_pageanalytics` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `views` int unsigned NOT NULL,
  `unique_views` int unsigned NOT NULL,
  `bounce_rate` decimal(5,2) NOT NULL,
  `avg_time_on_page` bigint DEFAULT NULL,
  `page_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_pageanalytics_page_id_date_a806cbc7_uniq` (`page_id`,`date`),
  CONSTRAINT `pages_pageanalytics_page_id_40ecd541_fk_pages_page_id` FOREIGN KEY (`page_id`) REFERENCES `pages_page` (`id`),
  CONSTRAINT `pages_pageanalytics_chk_1` CHECK ((`views` >= 0)),
  CONSTRAINT `pages_pageanalytics_chk_2` CHECK ((`unique_views` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_pagecategory` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_pagemedia` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `media_type` varchar(20) NOT NULL,
  `file` varchar(100) NOT NULL,
  `alt_text` varchar(200) NOT NULL,
  `caption` varchar(500) NOT NULL,
  `order` int unsigned NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `page_id` bigint NOT NULL,
  `uploaded_by_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pages_pagemedia_page_id_b5e7fbee_fk_pages_page_id` (`page_id`),
  KEY `pages_pagemedia_uploaded_by_id_e096938f_fk_users_user_id` (`uploaded_by_id`),
  CONSTRAINT `pages_pagemedia_page_id_b5e7fbee_fk_pages_page_id` FOREIGN KEY (`page_id`) REFERENCES `pages_page` (`id`),
  CONSTRAINT `pages_pagemedia_uploaded_by_id_e096938f_fk_users_user_id` FOREIGN KEY (`uploaded_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `pages_pagemedia_chk_1` CHECK ((`order` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_pagerevision` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `content` longtext NOT NULL,
  `excerpt` longtext NOT NULL,
  `meta_title` varchar(60) NOT NULL,
  `meta_description` varchar(160) NOT NULL,
  `revision_note` varchar(200) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `created_by_id` bigint NOT NULL,
  `page_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pages_pagerevision_created_by_id_b3ce453e_fk_users_user_id` (`created_by_id`),
  KEY `pages_pagerevision_page_id_c8adaff4_fk_pages_page_id` (`page_id`),
  CONSTRAINT `pages_pagerevision_created_by_id_b3ce453e_fk_users_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `pages_pagerevision_page_id_c8adaff4_fk_pages_page_id` FOREIGN KEY (`page_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages_pagetemplate` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `template_type` varchar(20) NOT NULL,
  `template_file` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `preview_image` varchar(100) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `image` longtext,
  `meta_title` varchar(200) NOT NULL,
  `meta_description` longtext NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `parent_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `slug` (`slug`),
  KEY `products_category_parent_id_3388f6c9_fk_products_category_id` (`parent_id`),
  CONSTRAINT `products_category_parent_id_3388f6c9_fk_products_category_id` FOREIGN KEY (`parent_id`) REFERENCES `products_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `products_category` VALUES (1,'Short Wallet','short-wallet','','http://127.0.0.1:8000/media/categories/Generated_Image_October_15_2025_-_1_08AM.png','','',1,'2025-11-14 19:12:01.865791','2025-11-14 19:12:01.865791',NULL);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `slug` varchar(200) NOT NULL,
  `description` longtext NOT NULL,
  `short_description` varchar(300) NOT NULL,
  `sku` varchar(100) NOT NULL,
  `barcode` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `compare_price` decimal(10,2) DEFAULT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  `stock_quantity` int unsigned NOT NULL,
  `low_stock_threshold` int unsigned NOT NULL,
  `track_inventory` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_featured` tinyint(1) NOT NULL,
  `is_digital` tinyint(1) NOT NULL,
  `weight` decimal(8,2) DEFAULT NULL,
  `dimensions` varchar(100) NOT NULL,
  `meta_title` varchar(200) NOT NULL,
  `meta_description` longtext NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `category_id` bigint NOT NULL,
  `custom_express_shipping` decimal(8,2) DEFAULT NULL,
  `custom_shipping_dhaka` decimal(8,2) DEFAULT NULL,
  `custom_shipping_outside` decimal(8,2) DEFAULT NULL,
  `shipping_type` varchar(20) NOT NULL,
  `has_express_shipping` tinyint(1) NOT NULL,
  `youtube_video_url` varchar(200) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  UNIQUE KEY `sku` (`sku`),
  KEY `products_pr_is_acti_2fee29_idx` (`is_active`,`is_featured`),
  KEY `products_pr_categor_50f5f1_idx` (`category_id`,`is_active`),
  KEY `products_pr_price_9b1a5f_idx` (`price`),
  CONSTRAINT `products_product_category_id_9b594869_fk_products_category_id` FOREIGN KEY (`category_id`) REFERENCES `products_category` (`id`),
  CONSTRAINT `products_product_chk_1` CHECK ((`stock_quantity` >= 0)),
  CONSTRAINT `products_product_chk_2` CHECK ((`low_stock_threshold` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `products_product` VALUES (1,'One Part Leather Luxury Wallet','one-part-leather-luxury-wallet','<p>onepart</p>','','','',850.00,1050.00,380.00,0,5,1,1,0,0,NULL,'','','','2025-11-14 19:13:21.323916','2025-11-14 19:14:33.518524',1,NULL,NULL,NULL,'standard',0,'',1),(2,'One Part Leather Luxury Wallet (Copy)','one-part-leather-luxury-wallet-copy','<p>onepart</p>','','COPY-BDE955FA','',850.00,1050.00,380.00,0,5,1,1,0,0,NULL,'','','','2025-11-15 17:12:06.192636','2025-11-15 17:12:24.741439',1,NULL,NULL,NULL,'standard',0,'',0);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_productimage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(500) NOT NULL,
  `alt_text` varchar(200) NOT NULL,
  `is_primary` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_productimage_product_id_e747596a_fk_products_product_id` (`product_id`),
  CONSTRAINT `products_productimage_product_id_e747596a_fk_products_product_id` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `products_productimage` VALUES (1,'/media/categories/MW02-Chocolate-font_mhCNt48_20251026_024230_b2513b.jpg','MW02-Chocolate-font_mhCNt48_20251026_024230_b2513b.jpg',1,'2025-11-14 19:13:55.540276',1),(2,'/media/reviews/IMG_20250620_182034_169529569428.png','IMG_20250620_182034_169529569428.png',0,'2025-11-14 19:14:31.774393',1),(3,'/media/reviews/IMG_20250620_182937_364-2115097251_1.png','IMG_20250620_182937_364-2115097251_1.png',0,'2025-11-14 19:14:31.777395',1),(4,'/media/reviews/IMG_20250620_182203_3891164927352_1.png','IMG_20250620_182203_3891164927352_1.png',0,'2025-11-14 19:14:31.778396',1),(5,'/media/categories/MW02-Chocolate-font_mhCNt48_20251026_024230_b2513b.jpg','MW02-Chocolate-font_mhCNt48_20251026_024230_b2513b.jpg (Copy)',1,'2025-11-15 17:12:06.196639',2),(6,'/media/reviews/IMG_20250620_182034_169529569428.png','IMG_20250620_182034_169529569428.png (Copy)',0,'2025-11-15 17:12:06.198641',2),(7,'/media/reviews/IMG_20250620_182937_364-2115097251_1.png','IMG_20250620_182937_364-2115097251_1.png (Copy)',0,'2025-11-15 17:12:06.199643',2),(8,'/media/reviews/IMG_20250620_182203_3891164927352_1.png','IMG_20250620_182203_3891164927352_1.png (Copy)',0,'2025-11-15 17:12:06.201645',2);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_productvariant` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `sku` varchar(100) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `stock_quantity` int unsigned NOT NULL,
  `size` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `material` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL,
  `image` varchar(500) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  `compare_price` decimal(10,2) DEFAULT NULL,
  `cost_price` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sku` (`sku`),
  KEY `products_productvari_product_id_d9c22902_fk_products_` (`product_id`),
  CONSTRAINT `products_productvari_product_id_d9c22902_fk_products_` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `products_productvariant_chk_1` CHECK ((`stock_quantity` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_review` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `rating` smallint unsigned NOT NULL,
  `title` varchar(200) NOT NULL,
  `comment` longtext NOT NULL,
  `is_approved` tinyint(1) NOT NULL,
  `is_verified_purchase` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL,
  `user_id` bigint DEFAULT NULL,
  `guest_email` varchar(254) NOT NULL,
  `guest_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_review_product_id_d933ffa7` (`product_id`),
  KEY `products_review_user_id_2e53b831_fk_users_user_id` (`user_id`),
  KEY `products_re_product_55bfcf_idx` (`product_id`,`is_approved`),
  KEY `products_re_created_7e194a_idx` (`created_at`),
  CONSTRAINT `products_review_product_id_d933ffa7_fk_products_product_id` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `products_review_user_id_2e53b831_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `products_review_chk_1` CHECK ((`rating` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_reviewimage` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(100) NOT NULL,
  `caption` varchar(200) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `review_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `products_reviewimage_review_id_c90b3860_fk_products_review_id` (`review_id`),
  CONSTRAINT `products_reviewimage_review_id_c90b3860_fk_products_review_id` FOREIGN KEY (`review_id`) REFERENCES `products_review` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products_wishlist` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_wishlist_user_id_product_id_dcf61f93_uniq` (`user_id`,`product_id`),
  KEY `products_wishlist_product_id_7c798228_fk_products_product_id` (`product_id`),
  CONSTRAINT `products_wishlist_product_id_7c798228_fk_products_product_id` FOREIGN KEY (`product_id`) REFERENCES `products_product` (`id`),
  CONSTRAINT `products_wishlist_user_id_eea5692f_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restore_records` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `uploaded_database_file` varchar(100) DEFAULT NULL,
  `uploaded_media_file` varchar(100) DEFAULT NULL,
  `restore_type` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  `overwrite_existing` tinyint(1) NOT NULL,
  `backup_before_restore` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `started_at` datetime(6) DEFAULT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `description` longtext NOT NULL,
  `error_message` longtext NOT NULL,
  `backup_record_id` bigint DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `pre_restore_backup_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `restore_records_backup_record_id_f5022c7e_fk_backup_records_id` (`backup_record_id`),
  KEY `restore_records_created_by_id_293a0edd_fk_users_user_id` (`created_by_id`),
  KEY `restore_records_pre_restore_backup_i_dd3754d9_fk_backup_re` (`pre_restore_backup_id`),
  CONSTRAINT `restore_records_backup_record_id_f5022c7e_fk_backup_records_id` FOREIGN KEY (`backup_record_id`) REFERENCES `backup_records` (`id`),
  CONSTRAINT `restore_records_created_by_id_293a0edd_fk_users_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `users_user` (`id`),
  CONSTRAINT `restore_records_pre_restore_backup_i_dd3754d9_fk_backup_re` FOREIGN KEY (`pre_restore_backup_id`) REFERENCES `backup_records` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_checkoutcustomization` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `page_title` varchar(200) NOT NULL,
  `page_subtitle` varchar(300) NOT NULL,
  `customer_section_title` varchar(200) NOT NULL,
  `full_name_label` varchar(100) NOT NULL,
  `full_name_placeholder` varchar(200) NOT NULL,
  `full_name_default` varchar(200) NOT NULL,
  `email_label` varchar(100) NOT NULL,
  `email_placeholder` varchar(200) NOT NULL,
  `email_default` varchar(200) NOT NULL,
  `phone_label` varchar(100) NOT NULL,
  `phone_placeholder` varchar(200) NOT NULL,
  `phone_default` varchar(200) NOT NULL,
  `shipping_section_title` varchar(200) NOT NULL,
  `address_label` varchar(100) NOT NULL,
  `address_placeholder` varchar(500) NOT NULL,
  `address_default` longtext NOT NULL,
  `instructions_section_title` varchar(200) NOT NULL,
  `instructions_label` varchar(100) NOT NULL,
  `instructions_placeholder` varchar(500) NOT NULL,
  `instructions_help_text` varchar(200) NOT NULL,
  `shipping_method_section_title` varchar(200) NOT NULL,
  `delivery_location_label` varchar(100) NOT NULL,
  `dhaka_location_label` varchar(100) NOT NULL,
  `outside_location_label` varchar(100) NOT NULL,
  `payment_section_title` varchar(200) NOT NULL,
  `cod_label` varchar(100) NOT NULL,
  `bkash_label` varchar(100) NOT NULL,
  `nagad_label` varchar(100) NOT NULL,
  `bkash_merchant_number` varchar(20) NOT NULL,
  `nagad_merchant_number` varchar(20) NOT NULL,
  `bkash_instructions` longtext NOT NULL,
  `nagad_instructions` longtext NOT NULL,
  `cod_instructions` longtext NOT NULL,
  `bkash_transaction_label` varchar(100) NOT NULL,
  `bkash_transaction_placeholder` varchar(200) NOT NULL,
  `bkash_sender_label` varchar(100) NOT NULL,
  `bkash_sender_placeholder` varchar(200) NOT NULL,
  `nagad_transaction_label` varchar(100) NOT NULL,
  `nagad_transaction_placeholder` varchar(200) NOT NULL,
  `nagad_sender_label` varchar(100) NOT NULL,
  `nagad_sender_placeholder` varchar(200) NOT NULL,
  `order_summary_title` varchar(200) NOT NULL,
  `subtotal_label` varchar(100) NOT NULL,
  `shipping_label` varchar(100) NOT NULL,
  `tax_label` varchar(100) NOT NULL,
  `total_label` varchar(100) NOT NULL,
  `place_order_button_text` varchar(100) NOT NULL,
  `security_ssl_text` varchar(100) NOT NULL,
  `security_safe_text` varchar(100) NOT NULL,
  `trust_section_title` varchar(200) NOT NULL,
  `fast_shipping_title` varchar(100) NOT NULL,
  `fast_shipping_description` varchar(200) NOT NULL,
  `easy_returns_title` varchar(100) NOT NULL,
  `easy_returns_description` varchar(200) NOT NULL,
  `support_title` varchar(100) NOT NULL,
  `support_description` varchar(200) NOT NULL,
  `breadcrumb_home` varchar(50) NOT NULL,
  `breadcrumb_cart` varchar(50) NOT NULL,
  `breadcrumb_checkout` varchar(50) NOT NULL,
  `show_breadcrumb` tinyint(1) NOT NULL,
  `show_trust_badges` tinyint(1) NOT NULL,
  `show_security_badges` tinyint(1) NOT NULL,
  `show_order_summary` tinyint(1) NOT NULL,
  `primary_color` varchar(7) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `background_color` varchar(7) NOT NULL,
  `loading_cart_message` varchar(200) NOT NULL,
  `loading_shipping_message` varchar(200) NOT NULL,
  `processing_order_message` varchar(200) NOT NULL,
  `order_success_message` varchar(200) NOT NULL,
  `order_error_message` varchar(200) NOT NULL,
  `validation_error_message` varchar(200) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `settings_checkoutcustomization` VALUES (1,'Checkout','Complete your order','Customer Informations','Name','Enter your full name','','Email Address *','Enter your email address','','Phone Number *','Enter your phone number','','Shipping Address','Street Address','Enter your complete address','','Order Instructions','Special Instructions (Optional)','Any special delivery instructions, gift messages, or notes for your order...','Maximum 500 characters','Shipping Method','Delivery Location *','Dhaka City','Outside Dhaka','Payment Method','Cash on Delivery','bKash','Nagad','01XXXXXXXXX','01XXXXXXXXX','Follow these steps:\n1. Go to your bKash Mobile Menu by dialing *247#\n2. Choose \"Send Money\"\n3. Enter Merchant bKash Account Number: {merchant_number}\n4. Enter the total amount: {amount}\n5. Enter a reference: Your phone number\n6. Now enter your bKash Mobile Menu PIN and confirm','Follow these steps:\n1. Go to your Nagad Mobile Menu by dialing *167#\n2. Choose \"Send Money\"\n3. Enter Merchant Nagad Account Number: {merchant_number}\n4. Enter the total amount: {amount}\n5. Enter a reference: Your phone number\n6. Now enter your Nagad PIN and confirm','Payment Information:\n• Pay cash when you receive your order\n• Make sure to have exact amount ready\n• Our delivery person will collect the payment\n• You can inspect the product before payment','bKash Transaction ID *','Enter transaction ID after payment','Sender Mobile Number *','01XXXXXXXXX','Nagad Transaction ID *','Enter transaction ID after payment','Sender Mobile Number *','01XXXXXXXXX','Order Summary','Subtotal:','Shipping:','Tax:','Total:','Place Order','SSL Secured','Safe Checkout','Why shop with us?','Fast Shipping','Free shipping on orders over $50','Easy Returns','30-day return policy','24/7 Support','Customer service available','Home','Cart','Checkout',1,1,1,1,'#930000','#930000','#f8fafc','Loading order items...','Loading shipping options...','Processing...','Order placed successfully!','Error processing order. Please try again.','Please check your information and try again.',1,'2025-11-15 16:56:53.029860','2025-11-15 16:56:53.038372');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_curier` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `api_url` varchar(255) NOT NULL,
  `api_key` varchar(255) NOT NULL,
  `secret_key` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_herocontent` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(200) NOT NULL,
  `subtitle` varchar(300) NOT NULL,
  `desktop_image` varchar(500) DEFAULT NULL,
  `mobile_image` varchar(500) DEFAULT NULL,
  `primary_button_text` varchar(100) NOT NULL,
  `primary_button_url` varchar(200) NOT NULL,
  `secondary_button_text` varchar(100) NOT NULL,
  `secondary_button_url` varchar(200) NOT NULL,
  `text_color` varchar(7) NOT NULL,
  `text_shadow` tinyint(1) NOT NULL,
  `background_color` varchar(7) NOT NULL,
  `background_gradient` varchar(200) NOT NULL,
  `display_order` int unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `settings_herocontent_chk_1` CHECK ((`display_order` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `settings_herocontent` VALUES (3,'','','media/products/Screenshot.png','media/products/Screenshot.png','Shop Now','/products/','Browse Categories','/categories/','#ffffff',1,'#930000','',1,1,'2025-11-15 15:47:12.670794','2025-11-15 15:47:12.670794');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_integrationsettings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `meta_pixel_code` longtext,
  `meta_pixel_enabled` tinyint(1) NOT NULL,
  `google_analytics_code` longtext,
  `google_analytics_measurement_id` varchar(50) DEFAULT NULL,
  `google_analytics_enabled` tinyint(1) NOT NULL,
  `google_search_console_code` varchar(100) DEFAULT NULL,
  `google_search_console_enabled` tinyint(1) NOT NULL,
  `bing_webmaster_code` varchar(100) DEFAULT NULL,
  `bing_webmaster_enabled` tinyint(1) NOT NULL,
  `yandex_verification_code` varchar(100) DEFAULT NULL,
  `yandex_verification_enabled` tinyint(1) NOT NULL,
  `header_scripts` longtext,
  `footer_scripts` longtext,
  `gtm_container_id` varchar(20) DEFAULT NULL,
  `gtm_enabled` tinyint(1) NOT NULL,
  `hotjar_site_id` varchar(20) DEFAULT NULL,
  `hotjar_enabled` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `settings_integrationsettings` VALUES (1,'',0,'','',0,'',0,'',0,'',0,'','','',0,'',0,1,'2025-11-15 15:07:40.987893','2025-11-15 17:10:46.860992');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings_sitesettings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `site_name` varchar(200) NOT NULL,
  `site_tagline` varchar(300) NOT NULL,
  `site_logo` varchar(500) DEFAULT NULL,
  `site_favicon` varchar(500) DEFAULT NULL,
  `contact_phone` varchar(20) NOT NULL,
  `contact_email` varchar(254) NOT NULL,
  `contact_address` longtext NOT NULL,
  `footer_logo` varchar(500) DEFAULT NULL,
  `footer_short_text` longtext NOT NULL,
  `facebook_link` varchar(200) DEFAULT NULL,
  `youtube_link` varchar(200) DEFAULT NULL,
  `quick_links_title` varchar(100) NOT NULL,
  `customer_service_title` varchar(100) NOT NULL,
  `home_text` varchar(50) NOT NULL,
  `home_url` varchar(200) NOT NULL,
  `products_text` varchar(50) NOT NULL,
  `products_url` varchar(200) NOT NULL,
  `categories_text` varchar(50) NOT NULL,
  `categories_url` varchar(200) NOT NULL,
  `about_text` varchar(50) NOT NULL,
  `about_url` varchar(200) NOT NULL,
  `contact_text` varchar(50) NOT NULL,
  `contact_url` varchar(200) NOT NULL,
  `track_order_text` varchar(50) NOT NULL,
  `track_order_url` varchar(200) NOT NULL,
  `return_policy_text` varchar(50) NOT NULL,
  `return_policy_url` varchar(200) NOT NULL,
  `shipping_info_text` varchar(50) NOT NULL,
  `shipping_info_url` varchar(200) NOT NULL,
  `fraud_checker_text` varchar(50) NOT NULL,
  `fraud_checker_url` varchar(200) NOT NULL,
  `faq_text` varchar(50) NOT NULL,
  `faq_url` varchar(200) NOT NULL,
  `copyright_text` varchar(200) NOT NULL,
  `why_shop_section_title` varchar(200) NOT NULL,
  `feature1_title` varchar(100) NOT NULL,
  `feature1_subtitle` varchar(200) NOT NULL,
  `feature2_title` varchar(100) NOT NULL,
  `feature2_subtitle` varchar(200) NOT NULL,
  `feature3_title` varchar(100) NOT NULL,
  `feature3_subtitle` varchar(200) NOT NULL,
  `feature4_title` varchar(100) NOT NULL,
  `feature4_subtitle` varchar(200) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `return_policy_content` longtext NOT NULL DEFAULT (_utf8mb4'• 30-day return window from delivery date\n• Items must be in original condition\n• Free return shipping on defective items\n• Refunds processed within 5-10 business days\n• Original packaging required for returns\n• Contact customer service to initiate returns'),
  `return_policy_title` varchar(200) NOT NULL,
  `shipping_info_content` longtext NOT NULL DEFAULT (_utf8mb4'• Free standard shipping on orders over $50\n• Express shipping available for $9.99\n• Orders processed within 1-2 business days\n• Delivery time: 3-7 business days\n• Free shipping on all orders within Bangladesh\n• International shipping available to select countries'),
  `shipping_info_title` varchar(200) NOT NULL,
  `custom_today_date` date DEFAULT NULL,
  `delivery_area_dhaka_label` varchar(100) NOT NULL,
  `delivery_area_outside_label` varchar(100) NOT NULL,
  `delivery_cutoff_time` time(6) NOT NULL,
  `dhaka_delivery_days_max` int unsigned NOT NULL,
  `dhaka_delivery_days_min` int unsigned NOT NULL,
  `outside_dhaka_delivery_days_max` int unsigned NOT NULL,
  `outside_dhaka_delivery_days_min` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `settings_sitesettings_chk_1` CHECK ((`dhaka_delivery_days_max` >= 0)),
  CONSTRAINT `settings_sitesettings_chk_2` CHECK ((`dhaka_delivery_days_min` >= 0)),
  CONSTRAINT `settings_sitesettings_chk_3` CHECK ((`outside_dhaka_delivery_days_max` >= 0)),
  CONSTRAINT `settings_sitesettings_chk_4` CHECK ((`outside_dhaka_delivery_days_min` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `settings_sitesettings` VALUES (3,'My Brand Store','Your one-stop shop for quality products','/media/products/MB-logo.png','/media/products/MB-favicon.png','+1 123-456-7890','contact@mybrandstore.com','123 Main Street, City, State 12345, Country',NULL,'Brief description about your store that appears in the footer','','','Quick Links','Customer Service','Home','/','Products','/products','Categories','/categories','About Us','/about','Contact','/contact','Track Order','/track-order','Return Policy','/return-policy','Shipping Info','/shipping-info','Fraud Checker','/fraud-checker','FAQ','/faq','© 2024 My Brand Store. All rights reserved.','Why Shop With Us?','Fast Delivery','Quick & reliable shipping','Quality Products','Premium quality guaranteed','24/7 Support','Round the clock assistance','Secure Payment','Safe & secure transactions',1,'2025-11-15 15:26:18.179773','2025-11-15 16:48:29.813041','• 30-day return window from delivery date\r\n• Items must be in original condition\r\n• Free return shipping on defective items\r\n• Refunds processed within 5-10 business days\r\n• Original packaging required for returns\r\n• Contact customer service to initiate returns','Return Policy','• Free standard shipping on orders over $50\r\n• Express shipping available for $9.99\r\n• Orders processed within 1-2 business days\r\n• Delivery time: 3-7 business days\r\n• Free shipping on all orders within Bangladesh\r\n• International shipping available to select countries','Shipping Information',NULL,'Inside Dhaka City','Outside Dhaka City','16:00:00.000000',2,1,3,1);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address_type` varchar(10) NOT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `country` varchar(100) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_address_user_id_address_type_is_default_807fc86d_uniq` (`user_id`,`address_type`,`is_default`),
  CONSTRAINT `users_address_user_id_4c106ba4_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_dashboardpermission` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `allowed_tabs` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `users_dashboardpermission_user_id_40c5c0f9_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `users_dashboardpermission` VALUES (1,'[\"products\", \"statistics\", \"home\", \"users\", \"settings\", \"orders\", \"categories\"]','2025-11-14 19:05:16.375802','2025-11-15 16:45:56.538530',1);
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `email` varchar(254) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `profile_picture` varchar(100) DEFAULT NULL,
  `address_line_1` varchar(255) NOT NULL,
  `address_line_2` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `postal_code` varchar(20) NOT NULL,
  `country` varchar(100) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `email_verification_sent_at` datetime(6) DEFAULT NULL,
  `is_email_verified` tinyint(1) NOT NULL,
  `password_reset_sent_at` datetime(6) DEFAULT NULL,
  `password_reset_token` char(32) DEFAULT NULL,
  `email_verification_token` char(32) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `users_user_email_verification_token_5a55bb13_uniq` (`email_verification_token`),
  UNIQUE KEY `users_user_password_reset_token_bdecdf45_uniq` (`password_reset_token`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `users_user` VALUES (1,'pbkdf2_sha256$1000000$2UQzYI5FR1sCBHtqRUt3Aa$VD4zBnnOq3ZwaLcSHObzuLbELdfBXDr8xanhQyca1hk=','2025-11-15 19:16:12.062317',1,'admin','','',1,1,'2025-11-14 19:05:15.445416','manobbazar@gmail.com','',NULL,'','','','','','','','2025-11-14 19:05:16.254268','2025-11-15 16:45:56.534527',NULL,1,NULL,NULL,'d4021ede35bf45bca040a0f4de05cce7'),(2,'pbkdf2_sha256$1000000$wIyvsjueRoXFIm4wrb1nQC$GiaNvM3SnMpIla2pfbfnF9sjMKCQ/PRBfgZK7kFyeiw=',NULL,1,'aminul3065','','',1,1,'2025-11-14 19:26:18.287836','aminul3065@gmail.com','',NULL,'','','','','','','','2025-11-14 19:26:19.086496','2025-11-14 19:26:19.086496',NULL,1,NULL,NULL,'9ce19a3e2c2a4fb1b0c7f26d8d90c361');
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_groups_user_id_group_id_b88eab82_uniq` (`user_id`,`group_id`),
  KEY `users_user_groups_group_id_9afc8d0e_fk_auth_group_id` (`group_id`),
  CONSTRAINT `users_user_groups_group_id_9afc8d0e_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `users_user_groups_user_id_5f6f5a90_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_user_user_permissions_user_id_permission_id_43338c45_uniq` (`user_id`,`permission_id`),
  KEY `users_user_user_perm_permission_id_0b93982e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `users_user_user_perm_permission_id_0b93982e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `users_user_user_permissions_user_id_20aca447_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users_userprofile` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `newsletter_subscription` tinyint(1) NOT NULL,
  `email_notifications` tinyint(1) NOT NULL,
  `sms_notifications` tinyint(1) NOT NULL,
  `preferred_currency` varchar(3) NOT NULL,
  `preferred_language` varchar(10) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `users_userprofile_user_id_87251ef1_fk_users_user_id` FOREIGN KEY (`user_id`) REFERENCES `users_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
INSERT INTO `users_userprofile` VALUES (1,1,1,0,'USD','en','2025-11-15 16:47:00.894316','2025-11-15 16:47:00.894316',1);
